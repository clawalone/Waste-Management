# Recyclify

**AIM**

Plastic recycling manufacturers provide a service to businesses and individual customers.
We can use these services for the disposal of plastic. While many people make the effort to
recycle, at this stage, most of them are stuck at the first step of plastic recycling, which is gathering
waste plastic products. While this process may seem like an easy task, it is not entirely so. A
platform that shows targeted locations to collectors to collect waste can make this step of
collection easier. As the world is digitalized, such platforms of doorstep plastic and E-Waste
collection will also motivate people to recycle more waste as their work of gathering waste and
then searching for waste collectors nearby is reduced. This will help to manage a lot of portions
of plastics and E-Waste.
