import PostSection from './Components/PostSection';
import './Components.Posts.styles.css';

function PostsPage() {
  return (
    <div className="postsPage">
      <PostSection></PostSection>
    </div>
  )
}

export default PostsPage;
