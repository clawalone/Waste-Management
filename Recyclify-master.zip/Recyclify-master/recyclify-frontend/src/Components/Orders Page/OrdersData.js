const OrdersData = [
    {
        "ID": "1",
        "CustomerName": "Shlok Hinge",
        "PhoneNo": "1023456789",
        "Address": "Pune Institute Of Computer Technology , Dhankawadi , Pune , 411047",
        "Type": "Plastic",
        "ApproxQuantity": "2kg",
        "Items": "bottles , broken plastic materials , bottles",
        "Img": "https://dl.airtable.com/.attachments/6c24084000a3777064c5200a8c2ae931/04081a3e/ireland.jpeg"
    },
    {
        "ID": "2",
        "CustomerName": "Abhijeet Ingle",
        "PhoneNo": "13425213467",
        "Address": "Dharmapuri, Forest Colony, Tajganj, Agra, Uttar Pradesh 282001, India Taj Mahal ",
        "Type": "E-Waste",
        "ApproxQuantity": "100",
        "Items": "I-phone 13",
        "Img": "https://dl.airtable.com/.attachments/a0cd0702c443f31526267f38ea5314a1/2447eb7a/paris.jpg"
    },
    {
        "ID": "3",
        "CustomerName": "Atharva Kinikar",
        "PhoneNo": "1324513467",
        "Address": "Dharmapuri, Forest Colony, Tajganj, Agra, Uttar Pradesh 282001, India Taj Mahal ",
        "Type": "Plastic",
        "ApproxQuantity": "14kg",
        "Items": "Bags,Bottles",
        "Img": "https://dl.airtable.com/.attachments/27f6cbfe631e303f98b97e9dafacf25b/6bbe2a07/vienna.jpeg"
    },
    {
        "ID": "4",
        "CustomerName": "Abhishek Jadhav",
        "PhoneNo": "13425213467",
        "Address": "Dharmapuri, Forest Colony, Tajganj, Agra, Uttar Pradesh 282001, India Taj Mahal ",
        "Type": "E-Waste",
        "ApproxQuantity": "1",
        "Items": "Lenovo Ideapad Slim 5",
        "Img": "https://dl.airtable.com/.attachments/3feee7a93af0f4f809312132090c9a80/58e3e8ec/poland.jpeg"
    }
]

export default OrdersData;